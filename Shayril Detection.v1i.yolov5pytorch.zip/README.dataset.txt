# Shayril Detection > 2022-08-01 3:20pm
https://universe.roboflow.com/object-detection/shayril-detection-rwdbr

Provided by Roboflow
License: CC BY 4.0

